"""
데이터 모듈
"""

from .provider import DataProvider

__all__ = ['DataProvider']